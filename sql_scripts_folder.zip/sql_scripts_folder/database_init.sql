
DROP DATABASE IF EXISTS ArtGallery;
CREATE DATABASE ArtGallery; 
USE ArtGallery;


DROP TABLE IF EXISTS Exhibitions;
CREATE TABLE Exhibitions (
	E_id_no integer not null,
	name_art varchar(100) not null,
	E_day varchar(100) not null,
	E_monh varchar(100) not null,
	E_year varchar(100) not null,
	S_day varchar(100) not null,
	S_month varchar(100) not null,
	S_year varchar(100) not null,
	primary key (E_id_no)
);

DROP TABLE IF EXISTS Art_Objects;
CREATE TABLE Art_Objects (
	id_no integer not null,
	Title varchar(100) not null,
	Descriptions varchar(100) not null,
	Epoche varchar(100) not null,
	year_num integer not null,
	origin varchar(100) not null,
	primary key (id_no),
	foreign key (id_no) references Exhibitions(E_id_no)
);

DROP TABLE IF EXISTS Painting;
CREATE TABLE Painting (
	id_no integer not null,
	paint_type varchar(100) not null,
	style varchar(100) not null,
	Drawn_on varchar(100) not null,
	primary key (id_no),
	foreign key (id_no) references Art_Objects(id_no)
);


DROP TABLE IF EXISTS Sculpture;
CREATE TABLE Sculpture (
	id_no integer not null,
	style varchar(100) not null,
	material varchar(100) not null,
	height integer not null,
	weights integer not null,
	primary key (id_no),
	foreign key (id_no) references Art_Objects(id_no)
);

DROP TABLE IF EXISTS Statue;
CREATE TABLE Statue (
	id_no integer not null,
	style varchar(100) not null,
	material varchar(100) not null,
	height integer not null,
	primary key (id_no),
	foreign key (id_no) references Art_Objects(id_no)
);

DROP TABLE IF EXISTS Other;
CREATE TABLE Other (
	id_no integer not null,
	style varchar(100) not null,
	types varchar(100) not null,
	primary key (id_no),
	foreign key (id_no) references Art_Objects(id_no)
);

DROP TABLE IF EXISTS Permanent_Collection;
CREATE TABLE Permanent_Collection (
	id_no integer not null,
	date_aquired integer not null,
	status_art varchar(100) not null,
	cost integer not null,
	primary key (id_no),
	foreign key (id_no) references Art_Objects(id_no)
);

DROP TABLE IF EXISTS Collections;
CREATE TABLE Collections (
	name_art varchar(100) not null,
	current_contact varchar(100) not null,
	types varchar(100) not null,
	Descriptions varchar(100) not null,
	Address_collection varchar(100) not null,
	Phone integer not null,
	primary key (name_art)
);

DROP TABLE IF EXISTS Borrowed;
CREATE TABLE Borrowed (
	id_no integer not null,
	date_borrowed integer not null,
	date_returned varchar(100) not null,
	c_name varchar(100) not null,
	primary key (id_no),
	foreign key (c_name) references Collections(name_art)
);



DROP TABLE IF EXISTS Artist;
CREATE TABLE Artist (
	name_artist varchar(100) not null,
	Descriptions varchar(100) not null,
	Main_style varchar(100) not null,
	country_of_origin varchar(100) not null,
	B_day varchar(100) not null,
	B_month varchar(100) not null,
	B_year varchar(100) not null,
	D_day varchar(100) not null,
	D_month varchar(100) not null,
	D_year varchar(100) not null,
	primary key(name_artist)
);

DROP TABLE IF EXISTS Made_by;
CREATE TABLE Made_by (
	name_artist varchar(100) not null,
	id_no integer not null,
	primary key (name_artist,id_no),
	foreign key (name_artist) references Artist(name_artist),
	foreign key (id_no) references Art_Objects(id_no)
);



DROP DATABASE IF EXISTS ArtGallery;
CREATE DATABASE ArtGallery; 
USE ArtGallery;



DROP TABLE IF EXISTS Exhibitions;
CREATE TABLE Exhibitions (
	E_id_no integer not null,
	name_art varchar(100) not null,
	E_day varchar(100) not null,
	E_month varchar(100) not null,
	E_year varchar(100) not null,
	S_day varchar(100) not null,
	S_month varchar(100) not null,
	S_year varchar(100) not null,
	primary key (E_id_no)
);

DROP TABLE IF EXISTS Art_Objects;
CREATE TABLE Art_Objects (
	id_no integer not null,
	Title varchar(100) not null,
	Descriptions varchar(100) ,
	Epoch varchar(100) not null,
	year_num integer not null,
	origin varchar(100) ,
    exh_no integer not null,
	primary key (id_no),
    foreign key (exh_no) references Exhibitions(E_id_no)
	
);

DROP TABLE IF EXISTS Painting;
CREATE TABLE Painting (
	id_no integer not null,
	paint_type varchar(100) not null,
	style varchar(100) not null,
	Drawn_on varchar(100) not null,
	primary key (id_no),
	foreign key (id_no) references Art_Objects(id_no)
);


DROP TABLE IF EXISTS Sculpture;
CREATE TABLE Sculpture (
	id_no integer not null,
	style varchar(100) ,
	material varchar(100) ,
	height integer ,
	weight integer ,
	primary key (id_no),
	foreign key (id_no) references Art_Objects(id_no)
);

DROP TABLE IF EXISTS Statue;
CREATE TABLE Statue (
	id_no integer not null,
	style varchar(100) ,
	material varchar(100) ,
	height integer ,
	primary key (id_no),
	foreign key (id_no) references Art_Objects(id_no)
);

DROP TABLE IF EXISTS Other;
CREATE TABLE Other (
	id_no integer not null,
	style varchar(100) not null,
	type varchar(100) not null,
	primary key (id_no),
	foreign key (id_no) references Art_Objects(id_no)
);

DROP TABLE IF EXISTS Permanent_Collection;
CREATE TABLE Permanent_Collection (
	id_no integer not null,
	date_acquired integer not null,
	status_art varchar(100) not null,
	cost integer ,
	primary key (id_no),
	foreign key (id_no) references Art_Objects(id_no)
);

DROP TABLE IF EXISTS Collections;
CREATE TABLE Collections (
	collec_name varchar(100) not null,
	current_contact varchar(100) not null,
	types varchar(100) not null,
	Descriptions varchar(150) ,
	Collection_address varchar(100) not null,
	Phone varchar (30) not null,
	primary key (collec_name)
);

DROP TABLE IF EXISTS Borrowed;
CREATE TABLE Borrowed (
	id_no integer not null,
	date_borrowed integer not null,
	date_returned integer not null,
	c_name varchar(100) not null,
	primary key (id_no),
	foreign key (c_name) references Collections(collec_name)
);



DROP TABLE IF EXISTS Artist;
CREATE TABLE Artist (
	name_artist varchar(100) not null,
	Descriptions varchar(100) ,
	Main_style varchar(100) ,
	country_of_origin varchar(100) ,
	B_day varchar(100) ,
	B_month varchar(100) ,
	B_year varchar(100) ,
	D_day varchar(100) ,
	D_month varchar(100) ,
	D_year varchar(100) ,
	primary key(name_artist)
);

DROP TABLE IF EXISTS Made_by;
CREATE TABLE Made_by (
	name_artist varchar(100) not null,
	id_no integer not null,
	primary key (name_artist,id_no),
	foreign key (name_artist) references Artist(name_artist),
	foreign key (id_no) references Art_Objects(id_no)
);


INSERT INTO Exhibitions ( E_id_no, name_art, E_day, E_month, E_year, S_day, S_month, S_year) 
values 
(199, "Cubism and the Trompe l’Oeil Tradition", 22, 01, 2023, 20, 10, 2022),
(955, "Hear Me Now: The Black Potters of Old Edgefield, South Carolina", 05, 02, 2023, 09, 09, 2022),
(899, "The Tudors: Art and Majesty in Renaissance England", 08, 01, 2023, 10, 10, 2022),
(159, "MASTERPIECES OF THE LOUVRE", 23, 02, 2023, 09, 15, 2022),
(274, "ACQUISITIONS MADE IN 2020", 13, 01, 2023, 11, 11, 2022);

INSERT INTO Art_Objects ( id_no, Title, Descriptions, Epoch, year_num, origin, exh_no)
values 
(0001, "Still Life with Four Bunches of Grapes", "A still life painting of grapes to demonstrate capturing 3D in 2D.", "Renaissance", 1636, "Spanish", 199),
(0002, "A Board with Letters, Quill Knife, and Quill Pen behind Red Straps",  "The painting makes the viewer think all elements of the painitng are authentic.", "Renaissance", 1658, "Amsterdam", 199),
(0003,"Glass, Newspaper, and Die","Picasso atemmpts trompe l’oeil themes where it appears as if objects were touchable." ,"20th Century", 1914, "Spanish", 199),
(0004, "Still Life", "This was an attempt of chantourné: imitating the shape of an object using other smaller ones.", "20th Century", 1914, "French", 199),
(0005, "Violin and Sheet Music: 'Petit Oiseau'","A multi-view of a violin in trompe l’oeil","20th Century" ,1913, "French",199 ),
(0006,"Field Armor of King Henry VIII of England", "A set of armor made for King Henry near the end of his life.", "Medieval", 1544, "Italian",899),
(0007,"John the Evangelist", null,"Medieval", 1505, null, 899),
(0008,"Face jug", "Face jugs were made by African American slaves/freedmen to perseve their culture.", "19th Century", 1867, "American", 955),
(0009, "Storage jar", null, "19th Century", 1840, "American", 955),
(0010, "Treasure chest of Louis XIV", "Five openwork gold panels with a decoration of various flowers and four lions paws.", "Renaissance", 1675, "French", 159),
(0011,"Stele", "It depicts the meeting between the god Shamash and King Hammurabi.","1st Dynasty of Babylon", -1792,"Iraqian", 159),
(0012, "The Waterfall", "It depcits a scene of waterfall", "18th Century", 1700, "France", 274),
(0013,"The Wedding at Cana", "Depicits the wedding where Jesus turns water into wine.", "Renaissance", 1500, "Italian", 274 ),
(0014,"The Genius of Sculpture", "A sketch for Falconet's reception piece.", "Renaissance", 1745, "France", 274),
(0015,"Rebel Slave", null, "Renaissance", 1514, "Italian", 159)
;


INSERT INTO Painting ( id_no, paint_type, style, Drawn_on)
values 
(0001, "Oil", "Still-life" , "Canvas"),
(0002, "Oil", "Letter Rack", "Canvas"),
(0005, "Oil and charcoal", "Abstract", "Canvas"),
(0012, "Oil", "Realism", "Cloth"),
(0013, "Oil", "Realism", "Canvas")
;

INSERT INTO Sculpture ( id_no, style, material, height, weight)
values 
(0003, "Abstract", "Oil, painted tin, iron wire, wood", "17.4", null),
(0004, "Abstract", "Painted wood and fabric upholstery fringe", "9.2", null),
(0014, "Realism", "Teracotta", 35, null)
;

INSERT INTO Statue ( id_no, style, material, height)
values 
(0006, "Medieval","Metal", 184),
(0007, "Medieval", "Teracotta", 48),
(0015, "Realism", "Marble", 215)
;

INSERT INTO Other ( id_no, style, type)
values 
(0008, "African alkane-glazed stoneware","Pottery"),
(0009, "African alkaline-glazed stoneware with kaolin and iron slip", "Pottery"),
(0010, "Decorative", "Box"),
(0011, "Decorative", "Stele")
;

INSERT INTO Permanent_Collection ( id_no, date_acquired, status_art, cost)
values 
(0001, 2019-06-01, "On Display", 4000000),
(0002, 2018-07-18, "On Display", 1600000),
(0003, 2019-08-02, "On Display", 3580202),
(0004, 2020-04-12, "On Display", 12358039),
(0005, 2016-01-15, "On Display", 98000000),
(0006, 2021-09-20, "On Display", 38002000),
(0007, 2018-02-04, "Loaned", 3000000),
(0008, 2012-12-23, "Loaned", 90000000),
(0009, 2015-01-20, "On Display", 0)
;

INSERT INTO Collections (collec_name, current_contact, types, Descriptions, Collection_address, Phone)
values 
( "MASTERPIECES OF THE LOUVRE", " Max Hollein", "Museum","Enriching the national collections is one of the Louvre’s core missions.Works are chosen after review by a 24-member Acquisitions Committee.", "99 Margaret Corbin Drive", "212-923-3700"),
("ACQUISITIONS MADE IN 2020", " Max Hollein", "Museum","Artworks essential to history and the history of art and through the ages", "99 Margaret Corbin Drive", "212-923-3700")
;

INSERT INTO Borrowed ( id_no, date_borrowed, date_returned, c_name)
values 
(0010, 2019-04-02, 2023-02-23, "MASTERPIECES OF THE LOUVRE"),
(0011, 2018-03-21, 2023-02-23, "MASTERPIECES OF THE LOUVRE"),
(0012, 2020-11-27, 2023-01-13, "ACQUISITIONS MADE IN 2020"),
(0013, 2020-09-20, 2023-01-13, "ACQUISITIONS MADE IN 2020"),
(0014, 2020-01-01, 2023-01-13, "ACQUISITIONS MADE IN 2020"),
(0015, 2021-07-17, 2023-02-23,"MASTERPIECES OF THE LOUVRE")
;

INSERT INTO Artist ( name_artist, Descriptions, Main_style, country_of_origin, B_day, B_month, B_year, D_day, D_month, D_year)
values 
("Juan Fernández 'el Labrador'", "El Labrador was known as the Zeuxis of his time due to his ability imitate nature into his art."," Caravaggisti", "Spain", null, null, 1629, null, null, 1636),
("Wallerant Valliant", "Wallerant Valliant painted during the Dutch Golden Age and co-invented the Mezzotint technique.", "Mezzotint", "Amsterdamn", 30, 05, 1623, 28, 08, 1677),
("Pablo Picasso","Pablo Picasso was very influential 20th century artist who co-founded Cubism" , "Cubism", "Spain", 25, 10, 1881, 08, 03, 1973),
("Blanck Jakob", "Blanck Jakob was a goldsmith", null, "France", null, null, null, null, null ,null),
("Paolo Caliari", "Paolo Callari was an Italian Renaissance painter known for large paintings.", "Realism", "Italy", null, null, 1528, 19, 04, 1588),
("Michelangelo di Lodovico Buonarroti Simoni", "Michaelangelo was an Italian sculptor, painter, and poet of the Renaisasace.", "Realism", "Italy", 06, 03, 1475, 18, 02, 1564)
;


INSERT INTO Made_by (name_artist, id_no)
values 
("Juan Fernández 'el Labrador'", 0001),
("Wallerant Valliant", 0002),
("Pablo Picasso", 0003),
("Pablo Picasso", 0004),
("Blanck Jakob", 0010),
("Paolo Caliari", 0013),
("Michelangelo di Lodovico Buonarroti Simoni", 0015)
;

