import mysql.connector as con
##Please use 'run and debug' mode.
def db_admin(cur):
    print(f'Menu options:\n1. Enter SQL Command.\n2. Run an SQL Script File.')
    choice1 = int(input('Enter 1 or 2: '))
    if choice1 == 1:
        query = input('Input the SQL Command You Wish to Run: \n')
        cur.execute(query)
        record = cur.fetchall()
        for tup in record:
            print(*tup, '\n')

    if choice1 == 2:
        filename = input('Enter filename here: ')
        fd = open(filename, 'r')
        sql_file = fd.read()
        fd.close()
        commands = sql_file.split(';')
        for command in commands:
            cur.execute(command)
            print(f'\n{command} executed.')

    cnx.commit()

def entry(cur):
    tables_info = {
'art_objects' : ['id_no', 'Title', 'Descriptions', 'Epoch', 'year_num','origin','exh_no'],
'artist' : ['name_artist', 'Descriptions', 'Main_style', 'country_of_origin',
'B_day', 'B_month', 'B_year', 'D_day', 'D_month', 'D_year'],
'borrowed' : ['id_no','date_borrowed','date_returned','c_name'],
'collections' : ['collec_name','current_contact','types','Descriptions','Collection_address','Phone'],
'exhibitions': ['E_id_no','name_art','E_day','E_month','E_year','S_day','S_month','S_year'],
'made_by': ['name_artist','id_no'],
'other': ['id_no','style','type'],
'painting': ['id_no','paint_type','style','Drawn_on'],
'permanent_collection': ['id_no','date_acquired','status_art','cost',],
'sculpture': ['id_no','style','material','height','weight'],
'statue': ['id_no','style','material','height']
}
    print('Menu options:\n\n1. Lookup info\n2. Insert info.\n3. Update info.\n4. Delete info.\n')
    choice1 = int(input('Select 1, 2, 3, or 4: '))

    if choice1 == 1:
        print('All table names:')
        for keys, value in tables_info.items():
            print(keys)
        table_choice = input('Please enter a table name you wish to lookup: ')
        print('Attributes you can learn about: ')
        print(f'{tables_info[table_choice]}')
        atts = input('Enter the name of attributes you wish to lookup (comma-seperated) or * for all: ')
        atts_list = list(atts.split(","))
        conds = input("Enter any conditions comma-seperated (ex: Drawn_on='Canvas',style='Realism') or press enter: ")
        conds_list = list(conds.split(","))
        conds = " AND ".join(conds_list)
        print(conds)
        query = 'SELECT ' + atts + ' FROM ' + table_choice
        if conds != '':
            query = query + ' WHERE ' + conds + ';'
        cur.execute(query)
        record = cur.fetchall()
        print(f'\n{tables_info[table_choice]}')
        for tup in record:
            print(*tup)
        cnx.commit()

    elif choice1 == 2:
        print('All table names:')
        for keys, value in tables_info.items():
            print(keys)
        table_choice = input('Please enter a table name you wish to insert to: ')
        print(f'Press 1 to insert through file, 2 to insert through commands: ')
        choice2 = int(input())

        if choice2 == 1:
            fname = input('Please enter .txt file name or path if not in same directory: ')
            fd = open(fname, 'r')
            sql_file = fd.read()
            print(sql_file)
            fd.close()
            atts_list = tables_info[table_choice]
            atts_fted = ' '.join(atts_list)
            atts_fted = atts_fted.replace(' ',',')
            atts_fted = '(' + atts_fted + ')'
            print(atts_fted)
            query = 'INSERT INTO ' + table_choice + atts_fted + '\n' + 'values' + '\n' + sql_file +';'
            print(query)
            cur.execute(query)
            cnx.commit()
            print(f'Info added to table {table_choice}')
        if choice2 == 2:
            iterations = int(input('How many tuples do you want to insert?'))
            for i in range(iterations):
                x = []
                query = 'INSERT INTO ' + table_choice + ' ('
                att_length = len(tables_info[table_choice])
                for i in range(att_length):
                    x.append(input(f'Enter data for {tables_info[table_choice][i]}: '))
                if i<=att_length - 2:
                    query = query + tables_info[table_choice][i] + ","
                atts_list = tables_info[table_choice]
                atts_fted = ' '.join(atts_list)
                atts_fted = atts_fted.replace(' ',',')
                query = query + atts_fted
                query = query + ")\nvalues\n"
                x_fted = ' '.join(x)
                x_fted = x_fted.replace(' ', ',')
                x_fted = '(' + x_fted + ')'
                query = query + x_fted
                cur.execute(query)
                cnx.commit()
                print('Row Inserted')
    if choice1 == 3:
            illegal = ['name_artist', 'id_no', 'collec_name', 'name_art', 'exh_no']
            table_choice = input('Please enter a table name you wish to update: ')
            print(f'Columns to choose from: {tables_info[table_choice]}')
            val_select = input('Enter a column you wish to update: ')
            if val_select in illegal or val_select not in tables_info[table_choice]:
                print('Attribute invalid.')
                return
            key_count = int(input('How many primary keys are in this table? '))
            key = []
            x = []
            for i in range(key_count):
                key.append(input('Enter the name of the primary key: '))
            x.append(input(f'Enter the new value of {val_select}: '))
            query = "UPDATE " + table_choice + " SET " + val_select + " = " + x[0] + "WHERE " 
            for i in range(len(key)):
                x.append(input(f'Enter the value of the primary key {key[i]}: '))
                query = query + key[i] + " =" + x[1]
            print(query)
            cur.execute(query)
            cnx.commit()
            print('Column Updated')
    if choice1 == 4:
            illegal = ['name_artist', 'id_no', 'collec_name', 'name_art', 'exh_no']
            parent = ['art_objects', 'artist', 'collections', 'exhibitions']
            table_choice = input('Please enter a table name you wish to delete from: ')
            if table_choice in parent:
                print('Table contains parent keys: cannot delete.')
                return
            num_search = int(input('How many attributes would you like to search with? '))
            x = []
            search = []
            print(tables_info[table_choice])
            for i in range(num_search):
                attribute = input('Enter the name of the search attribute: ' )
                val = input('Enter the value to be deleted')
                search.append(attribute)
                x.append(attribute)
            query = "DELETE FROM " + table_choice + " WHERE "
            for i in range(num_search):
                if (i < num_search-1):
                    query = f"{query}{search[i]} = '{val[i]}' AND"
                else:
                    query = f"{query}{search[i]} = '{val[i]}'"
            print(query)
            cur.execute(query)  
            cnx.commit()


def guest(cur):
    print("What data would you like to search for: \n 1 - Art Objects \n 2 - Exhibitions \n 3 - Artist")
    select = int(input("Enter your choice from the list above: (ie; 1 or 2 or 3)"))
    if select == '1':
        produce = ''
        art_type = input("Input 'P' to see Paintings \nInput 'S' for Sculpture \n Input 'ST' for Statue \n Input 'O' for other ")
        if art_type == 'P':
            produce = 'select * from art_objects natural join painting'
            cur.execute(produce)
        if art_type == 'S':
            produce = 'select * from art_objects natural join sculpture'
            cur.execute(produce)
        if art_type == 'ST':
            produce = 'select * from art_objects natural join statue'
            cur.execute(produce)
        if art_type == 'O':
            produce = 'select * from art_objects natural join other'
            cur.execute(produce)

        result = cur.fetchall()
        print(len(result), "Entries: \n")
        size_of_header = len(cur.column_names)
        for i in range(size_of_header):
            print("{:<15s}".format(str(values)),end = ' ')
        print()
        print(16*size_of_header*'-')
        for row in result:
            for values in row:
                print("{:<15s}".format(str(values)),end = ' ')
            print()
        rerun = input("\n input Y to go back to the guest interface or N to Quit")
        if rerun == 'Y':
            guest(cur)
        else:
            print("Goodbye!")
            quit()
    if select == '2':
        produce = 'se;ect * from exhibitions'
        cur.execute(produce)
        result = cur.fetchall()
        print(len(result), "Entries: \n")
        size_of_header = len(cur.column_names)
        for i in range(size_of_header):
            print("{:<40s}".format(str(values)),end = ' ')
        print()
        print(16*size_of_header*'-')
        for row in result:
            for values in row:
                print("{:<25s}".format(str(values)),end = ' ')
            print()
        rerun = input("\n input Y to go back to the guest interface or N to Quit")
        if rerun == 'Y':
            guest(cur)
        else:
            print("Goodbye!")
            quit()


    if select == '3':
        produce = 'select * from artist as art where art.id_no = %(id)s'
        select = input("enter id number of art piece inorder to display the artist") or None
        if select == None:
            produce = 'select * from artist'
            cur.execute(produce)
        else:
            cur.execute(produce,{'id':select})
        
        result = cur.fetchall()
        print(len(result), "Entries: \n")
        size_of_header = len(cur.column_names)
        for i in range(size_of_header):
            print("{:<15s}".format(str(values)),end = ' ')
        print()
        print(16*size_of_header*'-')
        for row in result:
            for values in row:
                print("{:<15s}".format(str(values)),end = ' ')
            print()
        rerun = input("\n input Y to go back to the guest interface or N to Quit")
        if rerun == 'Y':
            guest(cur)
        else:
            print("Goodbye!")
            quit()


print('Welcome to the ArtGallery database.')
print('1 - DB Admin')
print('2 - Data Entry')
print('3 - Browse as Guest')

user_selection = input('Enter 1, 2 or 3 to select your role: ')
print('For options 1 and 2 testing use username: za and passcode: pass. ')

if user_selection in ['1','2']:
    username = input('Username: ')
    passcode = input('Passcode: ')
    print('\n')
else:
    username = "guest"
    passcode = None


cnx = con.connect(
    host="127.0.0.1",
    port=3306,
    user=username,
    password=passcode,
    database='ArtGallery')


cur = cnx.cursor()
cur.execute("use artgallery")
if user_selection == '1':
    db_admin(cur)
if user_selection == '2':
    entry(cur)
if user_selection == '3':
    guest(cur)
