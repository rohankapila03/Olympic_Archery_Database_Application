select *
from information_schema.columns;

select*
from Art_Objects;

select*
from Permanent_Collection
order by cost asc;

select sculpture.height, sculpture.weight
from sculpture
where sculpture.id_no in(
select Art_Objects.id_no
from Art_Objects
where exh_no = 199);


select Permanent_Collection.cost, Permanent_Collection.date_acquired,  Art_Objects.Title, Art_Objects.Descriptions
from Art_Objects
	join Permanent_Collection
    on Permanent_Collection.id_no = Art_Objects.id_no;

Drop trigger if exists update_cost;
	DELIMITER $$
create trigger update_cost
before update on Permanent_Collection
for each row 
begin
	if old.cost != 0
then
	set new.cost = 0;
elseif old.cost = 0
then
	set new.cost= 99999;
end if;
end;
$$    


update Permanent_Collection
set cost = 0
where id_no = 0008;

update Permanent_Collection
set cost = 10000
where id_no = 0009;


select* 
from Permanent_Collection





Drop trigger if exists delete_artist;

	DELIMITER $$
create trigger delete_artist
before delete on Artist 
for each row
begin
	delete from Made_by
    where name_artist = old.name_artist;
end;
$$    

delete from Artist
where name_artist = "Pablo Picasso";

select* 
from Artist;

select*
from Made_by;

